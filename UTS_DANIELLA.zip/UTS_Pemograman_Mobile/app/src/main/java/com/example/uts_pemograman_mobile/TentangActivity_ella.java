package com.example.uts_pemograman_mobile;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class TentangActivity_ella extends AppCompatActivity {
Button btKembali;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tentang_ella);

        btKembali = findViewById(R.id.btKembali);
        btKembali.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent x = new Intent(TentangActivity_ella.this, MainActivity_ella.class);
                startActivity(x);
            }
        });
    }
}