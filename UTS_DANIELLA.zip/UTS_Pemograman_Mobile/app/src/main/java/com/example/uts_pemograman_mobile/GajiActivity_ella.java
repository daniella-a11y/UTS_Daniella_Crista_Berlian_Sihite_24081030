package com.example.uts_pemograman_mobile;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class GajiActivity_ella extends AppCompatActivity {
    EditText edNomor, edNama, edGaji, edTunjangan, edHari, edMakan, edTransportasi, edKotor, edBersih;
    Button btHitung;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gaji_ella);

        edNomor = findViewById(R.id.edNomor);
        edNama = findViewById(R.id.edNama);
        edGaji = findViewById(R.id.edGaji);
        edTunjangan = findViewById(R.id.edTunjangan);
        edHari = findViewById(R.id.edHari);
        edMakan = findViewById(R.id.edMakan);
        edTransportasi = findViewById(R.id.edTransportasi);
        edKotor = findViewById(R.id.edKotor);
        edBersih = findViewById(R.id.edBersih);

        btHitung = findViewById(R.id.btHitung);
        btHitung.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                float Hari = Float.parseFloat(edHari.getText().toString());
                float Gaji_pokok = Float.parseFloat(edGaji.getText().toString());
                float Tunjangan = Float.parseFloat(edTunjangan.getText().toString());

                double Tunjangan_transportasi = Hari * 5000;
                double Tunjangan_makan = Hari * 10000;
                double Gaji_Kotor = ((Gaji_pokok + Tunjangan + Tunjangan_transportasi+ Tunjangan_makan) * 0.1);

                edMakan.setText("" +Tunjangan_makan);
                edTransportasi.setText("" +Tunjangan_transportasi);
                edKotor.setText("" + Gaji_Kotor);
                edBersih.setText(""+ Gaji_pokok);




            }
        });


    }
}