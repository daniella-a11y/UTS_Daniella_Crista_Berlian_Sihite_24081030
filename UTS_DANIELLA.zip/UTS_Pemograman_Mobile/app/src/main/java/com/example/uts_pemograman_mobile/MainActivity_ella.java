package com.example.uts_pemograman_mobile;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivity_ella extends AppCompatActivity {
    CardView cvGaji, cvPetunjuk, cvTentang;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_ella);

        cvGaji = findViewById(R.id.cvGaji);
        cvGaji.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent x = new Intent(MainActivity_ella.this, GajiActivity_ella.class);
                startActivity(x);
            }
        });
        cvPetunjuk = findViewById(R.id.cvPetunjuk);
        cvPetunjuk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent x = new Intent(MainActivity_ella.this, PetunjukActivity_ella.class);
                startActivity(x);

            }
        });
        cvTentang = findViewById(R.id.cvTentang);
        cvTentang.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent x = new Intent(MainActivity_ella.this, TentangActivity_ella.class);
                startActivity(x);

            }
        });


    }
}